### Compatibility Patch Note

Due to deprecated internal imports in the `spherecluster` library (e.g., `sklearn.cluster.k_means_`),
manual patches were applied to ensure compatibility with `scikit-learn==0.24.2`.

These changes included:
- Replacing broken internal imports with public APIs or re-implemented equivalents.
- Removing unused or problematic components like `VonMisesFisherMixture`.
- Editing the `__init__.py` file to import only `SphericalKMeans`.

The environment was created using Python 3.9 and managed solely with pip and virtual environments — compliant with license restrictions. This allows the use of `SphericalKMeans` alongside `k-means` and `DBSCAN` without relying on Anaconda or source compilation.
