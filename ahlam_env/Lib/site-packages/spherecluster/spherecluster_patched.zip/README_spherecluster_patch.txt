README: Patched spherecluster for Python 3.9 + scikit-learn 0.24.2
==================================================================

This ZIP contains manually patched files for the `spherecluster` Python package,
modified to restore compatibility with a pip-only environment using:

- Python 3.9
- numpy==1.21.6
- scipy==1.7.3
- scikit-learn==0.24.2
- spherecluster==0.1.7

Patched Files
-------------
- spherical_kmeans.py
- __init__.py

Changes Made
------------
1. Replaced broken imports from:
   - `sklearn.cluster.k_means_`
   - `sklearn.externals.joblib`
   - `sklearn.cluster._k_means`
   With equivalent replacements or local fallback functions.

2. Removed import of `VonMisesFisherMixture` from `__init__.py` to prevent startup errors.

How to Use
----------
1. Copy the two patched files into your environment folder:
   Example:
   C:\Users\<YourUsername>\kmeans_env\Lib\site-packages\spherecluster\

2. Overwrite the existing files.

3. Test using:
   python -c "from spherecluster import SphericalKMeans; print('Spherical KMeans works!')"

4. (Optional) Lock your environment:
   pip freeze > requirements.txt

Report Snippet
--------------
Due to deprecated internal imports in the `spherecluster` library, manual patches were applied
to ensure compatibility with `scikit-learn==0.24.2`. These included updated import paths and
fallback definitions, allowing `SphericalKMeans` to function correctly without Anaconda or source compilation.
